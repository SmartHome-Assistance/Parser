#!/bin/sh

cat */etc/PROMPTS.log
rm */wav/*.fsg
rm */wav/*.gramm
rm */wav/*.sphinx
rm */etc/PROMPTS.log
