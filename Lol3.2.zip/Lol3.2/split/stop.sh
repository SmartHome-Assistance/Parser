#!/bin/sh

killall voice_spliter.pl
